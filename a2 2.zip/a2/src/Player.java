import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.nio.file.Paths;

public class Player {
    float x;
    static float y;
    static float left;
    static float right;
    static float top;
    static float bottom;

    static boolean firing = false;
    static Direction firingDirection = Direction.LEFT;

    static int level;

    static Image image;
    static ImageView imageView;

    Player (int level) {
        x = (float) (Const.screen_width/2);

        switch (level) {
            case 1:
                y = (float)(Const.pigMarginLv1);
            case 2:
                y = (float) (Const.pigMarginLv2);
            case 3:
                y = (float)(Const.pigMarginLv3);
        }



//        image = new Image("images/pigL.png", Const.pigWidth, Const.pigHeight, false, false);
//        imageView = new ImageView(image);

        left = x - Const.pigWidth/2;
        right = x + Const.pigWidth/2;
        top = y - Const.pigHeight/2;
        bottom = (float) (y + (0.6*Const.pigHeight));
    }

    static ImageView getImageView() {
        if (firing == true) {
            if (firingDirection == Direction.LEFT) {
                image = new Image("images/pigLfire.png", Const.pigWidth, Const.pigHeight, false, false);
            }
            else if (firingDirection == Direction.RIGHT) {
                image = new Image("images/pigRfire.png", Const.pigWidth, Const.pigHeight, false, false);
            }
        }
            else if (firing == false) {
                if (firingDirection == Direction.LEFT) {
                    image = new Image("images/pigL.png", Const.pigWidth, Const.pigHeight, false, false);}
                else if (firingDirection == Direction.RIGHT) {
                    image = new Image("images/pigR.png", Const.pigWidth, Const.pigHeight, false, false);
                }
        }
        imageView = new ImageView(image);
        imageView.setLayoutX(left);
        imageView.setLayoutY(top);
        return imageView;
    }


    static Bullet shoot(Direction direction) {
        MediaPlayer shootMediaPlayer =
                new MediaPlayer(new Media(Paths.get("sound/firecast.wav").toUri().toString()));
        shootMediaPlayer.play();
        if (direction == Direction.LEFT) {
            return new Bullet(Direction.LEFT, level, left,bottom);}
        else {
            return new Bullet(Direction.RIGHT, level, right,bottom);}
    }

//    ImageView getImageView() {
//        return imageView;
//    }

    public float getLeft() {
        System.out.println("left without this is" + left);
        return left;
    }
    public float getRight() {
        return right;
    }
    public float getTop() {
        return top;
    }
    public float getBottom() {
        return bottom;
    }
}


