import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.ArrayList;

enum Direction {
    LEFT,
    RIGHT
}

class Bullet {
    Direction direction;
    int bulletTime;
    double speed = 1;
    float x;
    float y;
    float left;
    float right;
    float top;
    float bottom;
    Image image;
    ImageView imageView;

    // todo: write step back - help avoid the case that keep depleting live.
    Bullet(Direction direction, int level, float x, float y) {
        this.direction = direction;
        this.x = x;
        this.y = y;
        switch (level) {
            case 1:
                this.bulletTime = Const.bulletTimeLv1;
                this.y = Const.labelBottomMarginLv1+100;
                break;
            case 2:
                this.bulletTime = Const.bulletTimeLv2;
                this.y = Const.labelBottomMarginLv2+100;
                break;
            case 3:
                this.bulletTime = Const.bulletTimeLv3;
                this.y = Const.labelBottomMarginLv3+100;
                break;
        }

        switch (direction){
            case LEFT:
                image = new Image("images/fireBallLeft.gif");
                break;
            case RIGHT:
                image = new Image("images/fireBallRight.gif");
                break;
        }
        this.imageView = new ImageView(image);

        left = x - Const.bullet_radius/2;
        right = x + Const.bullet_radius/2;
        top = y - Const.bullet_radius/2;
        bottom = y + Const.bullet_radius/2;
        imageView.setLayoutX(left);
        imageView.setLayoutY(top);
    }
    boolean inBound(){
        return right>=0 && left<=Const.screen_width;
    }

    void move(Direction direction) {
        switch (direction) {
            case RIGHT:
//                System.out.println("Entered right, current x ing:" + x);
                x += speed;
                left += speed;
                right += speed;
                break;
            case LEFT:
//                System.out.println("Entered left, current x ing:" + x);
                x -= speed;
                left -= speed;
                right -= speed;
                break;
        }
    }


    public ImageView getImageView() {
        return imageView;
    }
// return hit monster if hit, otherwise null.
    Monster hitCheck(Direction direction, ArrayList<Monster> activeMonsters) {
        switch (direction) {
            case LEFT:
                for (Monster monster: activeMonsters) {
                    // hard coded the x+20, as I really don't get why there is that inset on the screen
                    if (monster.direction == Direction.LEFT && monster.getAlive() && monster.x >=x) {
//                        System.out.println("HIT: current bullet x = " + x + " current monster x = " + monster.x);
                        return monster;
                    }
                }
                break;
            case RIGHT:
                for (Monster monster: activeMonsters) {
                    if (monster.direction == Direction.RIGHT && monster.getAlive() && monster.left <= x) {
//                        System.out.println("HIT: current x = " + x + " current monster x = " + monster.x);
                        return monster;
                    }
                }
                break;
        }
        return null;
    }
}
