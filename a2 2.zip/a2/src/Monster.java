import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.ArrayList;
import java.util.*;


public class Monster {
    // this direction refers to the direction the monster is spawned
    Direction direction;

    boolean alive;

    float x;
    float y;
    float left;
    float right;
    float top;
    float bottom;

    int level;

    Image image;
    ImageView imageView;

    Monster(boolean alive, int level) {
        int randomInt = (int) Math.round(Math.random());
        if (randomInt == 0) {
            this.direction = Direction.LEFT;
        }else {
            this.direction = Direction.RIGHT;
        }
        this.alive = alive;
        this.level = level;
        switch (this.direction) {
            case LEFT:
                image = new Image("images/enemyL.png",Const.monsterWidth,Const.monsterHeight,true,true);
                this.x = (float) (0);
                if (this.level == 1) {
                    this.y = (float) (Const.monsterBottomMarginLv1);
                } else if (this.level == 2) {
                    this.y = (float) (Const.monsterBottomMarginLv2);
                } else if (this.level == 3) {
                    this.y = (float) (Const.monsterBottomMarginLv3);
                }
                break;
            case RIGHT:
                image = new Image("images/enemyR.png",Const.monsterWidth,Const.monsterHeight,true,true);
                this.x = (float) (Const.screen_width);
                if (this.level == 1) {
                    this.y = (float) (Const.monsterBottomMarginLv1);
                } else if (this.level == 2) {
                    this.y = (float) (Const.monsterBottomMarginLv2);
                } else if (this.level == 3) {
                    this.y = (float) (Const.monsterBottomMarginLv3);
                }
                break;
        }
        this.imageView = new ImageView(image);
    }

    boolean hitCheck(Player player) {
        // if only one side of the monster exceed the player, then it hit the player -
        // 1) the right side of monster >= the left of player &&
        // the left side of monster < the left of player.
        //2) the left side of the monster < the right side of the player &&
        // the right side of the monster > the right side of the player.
//        System.out.println("monster x = " + this.x + "monster.left = " + this.left + "monster.right = " + this.right);
//        System.out.println("player Left  = " + player.getLeft() + "monster right = " + this.right + "player right "+ player.getRight());
        return (this.right >=player.x && this.left < player.x) ||
                (this.left <= player.getRight() + 30 && this.right > player.getRight()+30);
    }

    void stepBack(){
        switch (this.direction) {
            case LEFT:
                this.x -= 300;
//                this.alive = false;
                break;
            case RIGHT:
                this.x += 300;
//                this.alive = false;
                break;
        }
    }

    void move(Direction direction, int level) {
        switch (level) {
            case 1:
                if (direction == Direction.LEFT) {
                    this.x += Const.monsterSpeedLv1;
//                    this.left += Const.monsterSpeedLv1;
//                    this.right += Const.monsterSpeedLv1;
//                    System.out.println("level 1, Left, speed =  "+ Const.monsterBottomMarginLv1);
                } else if (direction == Direction.RIGHT) {
                    this.x -= Const.monsterSpeedLv1;
//                    this.left -= Const.monsterSpeedLv1;
//                    this.right -= Const.monsterSpeedLv1;
                }
                break;
            case 2:
                if (direction == Direction.LEFT) {
                    this.x += Const.monsterSpeedLv2;
//                    this.left += Const.monsterSpeedLv2;
//                    this.right += Const.monsterSpeedLv2;
//                    System.out.println("level 2, Left, speed =  "+ Const.monsterBottomMarginLv2);
                } else if (direction == Direction.RIGHT) {
                    this.x -= Const.monsterSpeedLv2;
                    this.left -= Const.monsterSpeedLv2;
                    this.right -= Const.monsterSpeedLv2;
                }
                break;
            case 3:
                if (direction == Direction.LEFT) {
                    this.x += Const.monsterSpeedLv3;
                    this.left += Const.monsterSpeedLv3;
                    this.right += Const.monsterSpeedLv3;
//                    System.out.println("level 3, Left, speed =  "+ Const.monsterBottomMarginLv3);
                } else if (direction == Direction.RIGHT) {
                    this.x -= Const.monsterSpeedLv3;
                    this.left -= Const.monsterSpeedLv3;
                    this.right -= Const.monsterSpeedLv3;
                }
                break;
        }
        this.left = this.x - Const.monsterWidth / 2;
        this.right = this.x + Const.monsterWidth / 2;
//        System.out.println("!!!monster x = " + this.x + "monster.left = " + this.left + "monster.right = " + this.right);
        this.top = this.y + Const.monsterHeight / 2;
        this.bottom = this.y - Const.monsterHeight / 2;

//        imageView.relocate(this.left,this.top);
        imageView.setLayoutX(this.left);;
        imageView.setLayoutY(this.top);
//        System.out.println("~~~ imageview x = " + imageView.getX() + "imageView layout X" + imageView.getLayoutX());
    }

    float getLeft() {
        return this.left;
    }

    float getRight() {
        return this.right;
    }

    float getTop() {
        return this.top;
    }

    float getBottom(){
        return this.bottom;
    }

    ImageView getImageView(){
        return this.imageView;
    }

    boolean getAlive(){
        return this.alive;
    }
    void setAlive(boolean alive){
        this.alive = alive;
    }
}

     class MonsterGroup {
        static ArrayList<Monster> monstersLeft = new ArrayList<>();
        static ArrayList<Monster> monstersRight= new ArrayList<>();;
        static ArrayList<Monster> allMonsters = new ArrayList<>();;

        float left;
        float right;
        float top;
        float bottom;
        float speed;

        MonsterGroup(int gameLevel){
            for (int i=0; i <40; i++) {
                Monster monster = new Monster(true, gameLevel);
                allMonsters.add(monster);
            }
            switch (gameLevel) {
                case 1:
                    this.speed = (float)(Const.monsterSpeedLv1);
                    break;
                case 2:
                    this.speed = (float)(Const.monsterSpeedLv2);
                    break;
                case 3:
                    this.speed = (float)(Const.monsterSpeedLv3);
                    break;
            }
            Collections.shuffle(allMonsters);
        //todo: 可能还有一些需要加的方法给这个group，比如random 生成， size e.g 一边10个， add into group。
        }


        void remove(Monster monster) {
            monster.setAlive(false);
            allMonsters.remove(monster);
        }

        void updateBoundLeft() {
            // what is the rightmost that the leftmost edge can be
            left = (float) Const.screen_width;
            right = 0;
            top = (float) Const.screen_height;
            bottom = 0;

            for (var monster : monstersLeft) {
                if (monster.alive){
                    left = Math.min(left, monster.getLeft());
                    right = Math.max(right, monster.getRight());
                    top = Math.min(top, monster.getTop());
                    bottom = Math.max(bottom, monster.getBottom());
                }
            }
        }
         void updateBoundRight() {
             // what is the rightmost that the leftmost edge can be
             left = (float) Const.screen_width;
             right = 0;
             top = (float) Const.screen_height;
             bottom = 0;

             for (var monster : monstersRight) {
                 if (monster.alive){
                     left = Math.min(left, monster.getLeft());
                     right = Math.max(right, monster.getRight());
                     top = Math.min(top, monster.getTop());
                     bottom = Math.max(bottom, monster.getBottom());
                 }
             }
        }
    }

