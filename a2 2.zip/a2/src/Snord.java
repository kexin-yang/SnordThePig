import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.text.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

//todo: load font from ttf file  http://java-buddy.blogspot.com/2013/02/load-true-type-font-ttf-in-javafx.html#:~:text=To%20load%20True%20Type%20Font,ttf%20file%20in%20%2Ffonts%20folder.
class Const {
    static final double screen_width = 1000;
    static final double screen_height = 500;
    static int score = 0;
    static int lives = 3;
    static int level = 1;

    static int pigWidth = 180;
    static int pigHeight = 150;
    static int monsterWidth =130;
    static int monsterHeight =150;
    // the lower inset from the ground of pig, in 3 levels
    static int pigMarginLv1 = 73;
    static int pigMarginLv2 = 133;
    static int pigMarginLv3 = 69;
    // the lower inset from the ground of monster, in 3 levels
    static int monsterBottomMarginLv1 = 65;
    static int monsterBottomMarginLv2 = 125;
    static int monsterBottomMarginLv3 = 60;

    static int labelBottomMarginLv1 = 7;
    static int labelBottomMarginLv2 = 25;
    static int labelBottomMarginLv3 = 7;


    static double monsterSpeedLv1 =  1.0;
    static double monsterSpeedLv2 =  2.0;
    static double monsterSpeedLv3 = 3.0;

    static int bulletTimeLv1 = 3;
    static int bulletTimeLv2 = 2;
    static int bulletTimeLv3 = 1;

    static int Layout_Space = 15;

    static int bullet_radius = 10;
}


class Intro {
    Stage stage;
    Image bg;
    ImageView bgImageView;
    Image logo;
    ImageView logoImageView;
    Label instructionTitle;
    Label instructionLabel;
    Label copyright;

    StackPane pane0;

    Intro(Stage stage) {
        this.stage = stage;
        stage.setTitle("Snord the Pig");
    }

    public void introScene() {
        bg = new Image("images/background.png", Const.screen_width, Const.screen_height, true, true);
        bgImageView = new ImageView(bg);
        pane0 = new StackPane();
        logo = new Image("images/logo.png", 0.5 * Const.screen_width, 0.5 * Const.screen_height, true, true);
        logoImageView = new ImageView(logo);
        instructionTitle = new Label("CONTROLS");
        instructionLabel = new Label(
                "PRESS ← OR → TO FIRE" + "\n" + "START GAME - ENTER" + "\n" + "START AT LEVEL - Press 1,2, OR 3" + "\n" +
                "Quit - Q");
        instructionTitle.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 40));
        instructionTitle.setTextAlignment(TextAlignment.CENTER);
        instructionTitle.setTextFill(Color.AZURE);
        instructionLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        instructionLabel.setTextAlignment(TextAlignment.CENTER);
        instructionLabel.setTextFill(Color.WHITE);
        copyright = new Label("Implemented by Kexin Yang, Jun. 2020, at University of Waterloo");
        copyright.setFont(new Font("Showcard Gothic", 9));
        copyright.setTextFill(Color.GRAY);

        StackPane.setAlignment(bgImageView, Pos.TOP_CENTER);
        StackPane.setAlignment(logoImageView, Pos.TOP_CENTER);
        StackPane.setMargin(logoImageView, new Insets(30));
        StackPane.setAlignment(instructionTitle, Pos.BOTTOM_CENTER);
        StackPane.setMargin(instructionTitle, new Insets(0, 0, 165, 0));
        StackPane.setAlignment(instructionLabel, Pos.BOTTOM_CENTER);
        StackPane.setMargin(instructionLabel, new Insets(0, 0, 20, 0));
        StackPane.setAlignment(copyright, Pos.BOTTOM_CENTER);
        pane0.getChildren().addAll(bgImageView, logoImageView, instructionTitle, instructionLabel, copyright);

        Scene scene0 = new Scene(pane0, Const.screen_width, Const.screen_height);

        MediaPlayer introMusic = new MediaPlayer(
                new Media(Paths.get("sound/hippop.mp3").toUri().toString()));
        introMusic.play();

        EventHandler<KeyEvent> switchScene = keyEvent -> {
            GamePlay game;
            switch(keyEvent.getCode()) {
                case ENTER:
                case DIGIT1:
                    game = new GamePlay(stage);
                    game.level(1,0);
                    break;
                case DIGIT2:
                    game = new GamePlay(stage);
                    game.level(2,0);
                    break;
                case DIGIT3:
                    game = new GamePlay(stage);
                    game.level(3,0);
                    break;
                case Q:
                    Quit.quit();
                    break;
            }
        };
        scene0.addEventHandler(KeyEvent.KEY_RELEASED, switchScene);
        stage.setScene(scene0);
        stage.show();
    }
}

class GamePlay {
    Stage stage;
    StackPane pane;
    Image bg;
    ImageView bgImageView;
    Image pigL_idle1;
    ImageView pigLImageViewIdle;
    Scene gameBoard;

    int playerShootCounter;
    int monsterNum = 0;

    MonsterGroup monsterGroup;
    Player player;

    static ArrayList<Monster> killedMonster = new ArrayList<>();
    static ArrayList<Bullet> activeBullets;
    static ArrayList<Monster> activeMonster;
    static ArrayList<Monster> stepBackMonster = new ArrayList<>();
//    static ArrayList<Player> playerList = new ArrayList<>();

    int curScore;
    int curLives;
    int curLevel;

    Label scoreLabel;
    String heartText;
    Label liveLabel;
    Label levelLabel;

    Timer timer;
    AnimationTimer animationTimer;

    GamePlay(Stage stage) {
        this.stage = stage;
        curScore = 0;
        curLives = Const.lives;
        curLevel = 0;
        pane = new StackPane();
        pigL_idle1 = new Image("images/pigL.png", Const.pigWidth, Const.pigHeight, true, true);
        pigLImageViewIdle = new ImageView(pigL_idle1);
        }

    void setScore(){
        pane.getChildren().remove(scoreLabel);
        scoreLabel = new Label("Score: " + curScore);
        scoreLabel.setTextAlignment(TextAlignment.LEFT);
        scoreLabel.setTextFill(Color.WHITE);
        scoreLabel.setFont(new Font("Arial", 30));
        // lv1
        pane.getChildren().add(scoreLabel);
        pane.setAlignment(scoreLabel, Pos.BOTTOM_LEFT);
        switch (curLevel){
            case 1:
                pane.setMargin(scoreLabel, new Insets(0, 0, Const.labelBottomMarginLv1, 20));
                break;
            case 2:
                pane.setMargin(scoreLabel, new Insets(0, 0, Const.labelBottomMarginLv2, 20));
                break;
            case 3:
                pane.setMargin(scoreLabel, new Insets(0, 0, Const.labelBottomMarginLv3, 20));
                break;
        }
    }

    void setLives() {
        pane.getChildren().remove(liveLabel);
        switch (curLives) {
            case 3:
                heartText = "❤❤❤";
                break;
            case 2:
                heartText = "❤❤";
                break;
            case 1:
                heartText = "❤";
                break;
            default:
                heartText = "❤❤❤";
                break;
        }
        liveLabel = new Label("Lives: " + curLives);
        liveLabel = new Label(heartText);
        liveLabel.setTextAlignment(TextAlignment.CENTER);
        liveLabel.setTextFill(Color.WHITE);
        liveLabel.setFont(new Font("Arial", 30));
        //lv1 margin.
        pane.getChildren().add(liveLabel);
        pane.setAlignment(liveLabel, Pos.BOTTOM_CENTER);
        switch (curLevel){
            case 1:
                pane.setMargin(liveLabel, new Insets(0, 0, Const.labelBottomMarginLv1, 0));
                break;
            case 2:
                pane.setMargin(liveLabel, new Insets(0, 0, Const.labelBottomMarginLv2, 0));
                break;
            case 3:
                pane.setMargin(liveLabel, new Insets(0, 0, Const.labelBottomMarginLv3, 0));
                break;
        }
    }

    void setLevel() {
        pane.getChildren().remove(levelLabel);
        levelLabel = new Label("Level: " + curLevel);
        levelLabel.setFont(new Font("Arial", 30));
        levelLabel.setTextAlignment(TextAlignment.RIGHT);
        levelLabel.setTextFill(Color.WHITE);
        // lv1 margin.
        pane.getChildren().add(levelLabel);
        pane.setAlignment(levelLabel, Pos.BOTTOM_RIGHT);
        switch (curLevel){
            case 1:
                pane.setMargin(levelLabel, new Insets(0, 25, Const.labelBottomMarginLv1, 0));
                break;
            case 2:
                pane.setMargin(levelLabel, new Insets(0, 25, Const.labelBottomMarginLv2, 0));
                break;
            case 3:
                pane.setMargin(levelLabel, new Insets(0, 25, Const.labelBottomMarginLv3, 0));
                break;
        }
    }

    //drawPig
    void setPlayer(){
//        for (var player: playerList) {
        pane.getChildren().remove(player.getImageView());
        ImageView pigImageView = Player.getImageView();
        pane.getChildren().add(pigImageView);
        switch (curLevel){
            case 1:
                pane.setAlignment(pigImageView, Pos.BOTTOM_CENTER);
                pane.setMargin(pigImageView, new Insets(0, 0, Const.pigMarginLv1, 0));
                break;
            case 2:
                pane.setAlignment(pigImageView, Pos.BOTTOM_CENTER);
                pane.setMargin(pigImageView, new Insets(0, 0, Const.pigMarginLv2, 0));
                break;
            case 3:
                pane.setAlignment(pigImageView, Pos.BOTTOM_CENTER);
                pane.setMargin(pigImageView, new Insets(0, 0, Const.pigMarginLv3, 0));
                break;
//        }
    }}
    void setBg() {
        switch (curLevel){
            case 1:
                bg = new Image("images/background1.jpg", Const.screen_width,
                        Const.screen_height, true, true);
                bgImageView = new ImageView(bg);
                break;
            case 2:
                bg = new Image("images/background2.png", Const.screen_width,
                        Const.screen_height, true, true);
                bgImageView = new ImageView(bg);
                break;
            case 3:
                bg = new Image("images/background3.jpg", Const.screen_width,
                        Const.screen_height, true, true);
                bgImageView = new ImageView(bg);
                break;
        }
        pane.getChildren().add(bgImageView);
        pane.setAlignment(bgImageView, Pos.TOP_CENTER);
    }

    void spawnMonster() {
        Monster monster = new Monster(true,curLevel);
        activeMonster.add(monster);
        switch (curLevel){
            case 1:
                monster.y = (int) (Const.screen_height-Const.monsterBottomMarginLv1);
                break;
            case 2:
                monster.y = (int) (Const.screen_height-Const.monsterBottomMarginLv2);
                break;
            case 3:
                monster.y = (int) (Const.screen_height-Const.monsterBottomMarginLv3);

                break;
            default:
                throw new IllegalStateException("Unexpected value: " + curLevel);
        }
        switch (monster.direction) {
            case LEFT:
                monster.x = 0 - Const.monsterWidth/2;
                break;
            case RIGHT:
                monster.x = (float) (Const.screen_width + Const.monsterWidth/2);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + monster.direction);
        }
    }
    // todo: win/lost 加背景。
    void drawMonster() {
        for (var monster : activeMonster){
            monster.move(monster.direction,curLevel);
            ImageView monsterImageView = monster.getImageView();
            pane.getChildren().remove(monsterImageView);
            pane.getChildren().add(monsterImageView);
            pane.setMargin(monsterImageView, new Insets(monster.y-0.5*Const.monsterHeight-20,
                    Const.screen_width-monster.x + Const.monsterWidth/2,
                    Const.screen_height-monster.y+0.2*Const.monsterHeight,
                    monster.x -Const.monsterWidth/2));
        }
    }

    void drawBullet(){
        for (var bullet : activeBullets){
            pane.getChildren().remove(bullet.getImageView());
            pane.setMargin(bullet.getImageView(), new Insets(
                    Const.screen_height-bullet.y,
            Const.screen_width-bullet.x-Const.bullet_radius,
                    bullet.y-Const.bullet_radius,
                    bullet.x-Const.bullet_radius));
            pane.getChildren().add(bullet.getImageView());
        }
    }

    public void level(int gameLevel, int score) {
        pane = new StackPane();
        gameBoard = new Scene(pane, Const.screen_width, Const.screen_height);
        stage.setScene(gameBoard);

        curLevel = gameLevel;
        curScore = score;

        monsterGroup = new MonsterGroup(curLevel);
        player = new Player(curLevel);

//        playerList.add(player);
        activeBullets = new ArrayList<>();
        activeMonster = new ArrayList<>();

        Label copyright = new Label("Implemented by Kexin Yang, Jun. 2020, at University of Waterloo");
        copyright.setFont(new Font("Showcard Gothic", 9));
        copyright.setTextFill(Color.GRAY);
        pane.setAlignment(copyright, Pos.BOTTOM_CENTER);
        pane.getChildren().addAll(copyright, pigLImageViewIdle);

        setBg();
        setLevel();
        setLives();
        setPlayer();
        setScore();

        timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                if (playerShootCounter > 0) playerShootCounter--;
                monsterNum = activeMonster.size();
                if (monsterNum < 2) spawnMonster();
                // if too many monsters in the list, pop the last one.
                if (monsterNum > 4) activeMonster.remove(activeMonster.get(activeMonster.size()-1));
            }};
        timer.schedule(task,0,1000);

        // handle fire, move left and right.
        EventHandler<KeyEvent> control = keyEvent -> {
            switch (keyEvent.getCode()) {
                case RIGHT:
                    if (playerShootCounter < 3) {
                        playerShootCounter++;
//                        pane.getChildren().remove(player.getImageView());
                        player.firing = true;
                        player.firingDirection = Direction.RIGHT;
                        setPlayer();
                        ImageView iv = player.getImageView();
                        pigMouth(iv);
//                        playerList.remove(player);
                        iv.setVisible(false);
                        Bullet bullet = Player.shoot(Direction.RIGHT);
                        bullet.move(Direction.RIGHT);
                        activeBullets.add(bullet);
                    }
                    break;
                case LEFT:
                    if (playerShootCounter < 3) {
                        playerShootCounter++;
                        pane.getChildren().remove(player.getImageView());
                        player.firing = true;
                        player.firingDirection = Direction.LEFT;
                        setPlayer();
//                        repaint();
                        ImageView iv = player.getImageView();
                        pigMouth(iv);
                        iv.setVisible(false);
                        Bullet bullet = Player.shoot(Direction.LEFT);
                        bullet.move(Direction.LEFT);
                        activeBullets.add(bullet);
                    }
                    break;
                case I:
                    Intro intro;
                    intro = new Intro(stage);
                    intro.introScene();
                    break;
                case Q:
                    Quit.quit();
                    break;
            }
        };

        gameBoard.addEventHandler(KeyEvent.KEY_PRESSED,control);

        animationTimer = new AnimationTimer() {
            @Override
            public void handle(long l) {
                handle_animation(pane);
            }
        };
        animationTimer.start();
    }
//    public void repaint() {
//        timer.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                Platform.runLater(new Runnable() {
//                    @Override
//                    public void run() {
//                        setBg();
//                        setLives();
//                        setScore();
//                        setLevel();
//                    }
//                });
//            }
//        }, 500);
//    }
    public void pigMouth(ImageView iv) {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        if (player.firing == true) {
                        iv.setVisible(false);
//                        playerList.remove(player);
                        pane.getChildren().remove(iv);
                        player.firing = false;
                        setBg();
                        setLives();
                        setScore();
                        setLevel();
                        setPlayer();
                        }
                    }
                });
            }
        }, 50);
    }

    public void handle_animation(StackPane pane){
        // draw player
//        pigMouth();

//        setPlayer();

        // handle draw monster
        drawMonster();

        //handle fireball.
        for (var bullet: activeBullets){
            Direction d = bullet.direction;
        if (!bullet.inBound()){
            activeBullets.remove(bullet);
            pane.getChildren().remove(bullet.getImageView());
            curScore -= 1;
            pane.getChildren().remove(scoreLabel);
            setScore();
            break;
        } else {
            bullet.move(d);
            drawBullet();}
        }

        //hit check - bullet hit monster?
        for (var bullet : activeBullets) {
            Direction d;
            switch (bullet.direction){
                case LEFT:
                    d = Direction.LEFT;
                    break;
                case RIGHT:
                    d = Direction.RIGHT;
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + bullet.direction);
            }
            Monster monster = bullet.hitCheck(d, activeMonster);
            if (monster != null) {
                activeMonster.remove(monster);
                MonsterGroup.allMonsters.remove(monster);
                killedMonster.add(monster);
                activeBullets.remove(bullet);
                pane.getChildren().remove(bullet.getImageView());
                pane.getChildren().remove(monster.getImageView());
                curScore += 1;
                pane.getChildren().remove(scoreLabel);
                setScore();
                MediaPlayer monsterHitSound = new MediaPlayer(
                        new Media(Paths.get("sound/kill_sound.wav").toUri().toString()));
                monsterHitSound.play();
                break;
            }
        }
        if (killedMonster.size() >=20) {
            killedMonster = new ArrayList<Monster>();
            animationTimer.stop();
            timer.cancel();
            if (curLevel == 3) {
                EndGame endGame = new EndGame(stage,curScore);
                endGame.win();
                return;
            }
            else{
                GamePlay game;
                game = new GamePlay(stage);
                game.level(curLevel+1,curScore);
            }
        }

        for (var monster: activeMonster) {
            if (monster.hitCheck(player)){
                MediaPlayer hitSound = new MediaPlayer(
                        new Media(Paths.get("sound/kill_sound.wav").toUri().toString()));
                hitSound.play();
                monster.stepBack();
                activeMonster.remove(monster);
                pane.getChildren().remove(monster.getImageView());
                if (curLives > 1) {
                    curLives--;
                    setLives();
                }
                else {
                    animationTimer.stop();
                    timer.cancel();
                    EndGame endGame = new EndGame(stage,curScore);
                    endGame.lose();
                }
            }
            return;
        }
    }

     void reduceLive() {
        switch (stepBackMonster.size()){
        case 1:
            System.out.println("curent Lives"+curLives);
            curLives = 2;
            setLives();
            break;
        case 2:
            System.out.println("curent Lives"+curLives);
            curLives = 1;
            setLives();
            break;
        case 3:
            System.out.println("curent Lives"+curLives);
            animationTimer.stop();
            timer.cancel();
            EndGame endGame = new EndGame(stage,curScore);
            endGame.lose();
            break;}
    }

    }
class EndGame {
    //todo: add background img.
    Stage stage;
    int score;

    EndGame(Stage stage, int score){
        this.stage = stage;
        this.score = score;
    }

    public void lose()
    {
        MediaPlayer loseSound = new MediaPlayer(
                new Media(Paths.get("sound/fail.wav").toUri().toString()));
        loseSound.play();
        StackPane paneLose = new StackPane();

        Image bgLoseImage = new Image("images/loseBackground.jpg", Const.screen_width, Const.screen_height, true, true);
        ImageView bgLoseImageView = new ImageView(bgLoseImage);


        Label gg1 = new Label("Game Over!\n");
        Label gg2 = new Label("Your score is " + this.score + "!");
        Label instruction = new Label("R - Replay."+"\n" +
                "Q - Quit.");

        gg1.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 50));
        gg2.setFont(Font.font("Arial", FontWeight.LIGHT, 35));
        instruction.setFont(Font.font("Arial", FontWeight.BOLD, 35));

        gg1.setTextFill(Color.AZURE);
        gg2.setTextFill(Color.AZURE);
        instruction.setTextFill(Color.PINK);

        gg1.setTextAlignment(TextAlignment.CENTER);
        gg1.setTextAlignment(TextAlignment.CENTER);
        instruction.setTextAlignment(TextAlignment.CENTER);

        paneLose.setAlignment(bgLoseImageView, Pos.TOP_CENTER);
        paneLose.setAlignment(gg1, Pos.TOP_CENTER);
        paneLose.setMargin(gg1, new Insets(40));
        paneLose.setAlignment(gg2, Pos.TOP_CENTER);
        paneLose.setMargin(gg2, new Insets(100));
        paneLose.setAlignment(instruction, Pos.BOTTOM_CENTER);
        paneLose.setMargin(instruction, new Insets(0, 0, 30, 0));

        paneLose.getChildren().addAll(bgLoseImageView,gg1,gg2,instruction);
        Scene loseScene = new Scene(paneLose, Const.screen_width, Const.screen_height);

        loseScene.setOnKeyPressed((e -> {
            GamePlay game;
            if (e.getCode() == KeyCode.Q) {
                Quit.quit();
            }
            else if (e.getCode() == KeyCode.R){
                game = new GamePlay(stage);
                game.level(1,0);
            }
        }));

        stage.setScene(loseScene);
    }

        public void win() {
        MediaPlayer winSound = new MediaPlayer(
                new Media(Paths.get("sound/won.mp3").toUri().toString()));
        winSound.play();


        StackPane paneWin = new StackPane();

        Image bgWinImage = new Image("images/winBackground.jpeg", Const.screen_width, Const.screen_height, true, true);
        ImageView bgWinImageView = new ImageView(bgWinImage);

        Label win1 = new Label("Congratulations, you won!");
        Label win2 = new Label("You score is " + this.score + " !");
        Label instruction = new Label("R - Replay. \n Q - Quit.");

        win1.setFont(Font.font("Arial", FontWeight.BOLD, 40));
        win2.setFont(Font.font("Arial", FontWeight.LIGHT, 30));
        instruction.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 40));

        win1.setTextFill(Color.PURPLE);
        win2.setTextFill(Color.PURPLE);
        instruction.setTextFill(Color.PINK);

        win1.setTextAlignment(TextAlignment.CENTER);
        win2.setTextAlignment(TextAlignment.CENTER);
        instruction.setTextAlignment(TextAlignment.CENTER);

        paneWin.setAlignment(bgWinImageView,Pos.TOP_CENTER);
        paneWin.setAlignment(win1,Pos.TOP_CENTER);
        paneWin.setMargin(win1, new Insets(60));
        paneWin.setAlignment(win2,Pos.TOP_CENTER);
        paneWin.setMargin(win2, new Insets(120));
        paneWin.setAlignment(instruction,Pos.TOP_CENTER);
        paneWin.setMargin(instruction, new Insets(190));
        paneWin.getChildren().addAll(bgWinImageView,win1,win2,instruction);
        Scene winScene = new Scene(paneWin, Const.screen_width, Const.screen_height);
        winScene.setOnKeyPressed((e -> {
            GamePlay game;
            if (e.getCode() == KeyCode.Q) {
                Quit.quit();
            }
            else if (e.getCode() == KeyCode.R){
                game = new GamePlay(stage);
                game.level(1,0);
            }
        }));
        stage.setScene(winScene);
    }
}


class Quit {
    public static void quit() {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Confirm");

        Label label = new Label ("Are you sure you want to quit?");
        label.setWrapText(true);
        Button yesButton = new Button("Yes");
        yesButton.setOnAction(event -> {
            window.close();
            System.exit(0);
        });

        Button noButton = new Button("No");
        noButton.setOnAction(event -> window.close());

        VBox layout = new VBox();
        layout.getChildren().addAll(label, yesButton, noButton);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 250, 300);
        window.setScene(scene);
        window.showAndWait();
    }
}

public class Snord extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        stage.setResizable(false);
        Intro intro = new Intro(stage);
        intro.introScene();
    }

}


