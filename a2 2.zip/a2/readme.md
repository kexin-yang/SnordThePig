A2

Kexin Yang
20868410


Short Cut:
In whichever level, you can press "I" to go back to the intro scene (Menu), where you can press 1,2,3 to go to the respective levels. 



Icon attribute:
Icons made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon"> www.flaticon.com</a>
Background image reference:
https://hipwallpaper.com/backgrounds-games/